
<?php
$dbServername = "localhost";
$dbUsername = "id14571922_devferanmi";
$dbPassword = "08107034667@walE";
$dbName ="id14571922_databaseme";
$conn = mysqli_connect($dbServername, $dbUsername,$dbPassword,$dbName);

// if(!$conn) {
// echo "Error";
// } 
// else {
// echo "successful";
// } 
?>